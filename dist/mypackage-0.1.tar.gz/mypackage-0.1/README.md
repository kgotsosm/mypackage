# mypackage

This library was made as part of a tutorial to create a pyhton package.